import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Navigation, MapPin, Clock, Car, TrendingUp, AlertTriangle, CheckCircle, Route } from 'lucide-react'
import { projectId, publicAnonKey } from '../utils/supabase/info'

interface RouteOptimizationProps {
  language: string
  translations: any
  user: any
}

export function RouteOptimization({ language, translations, user }: RouteOptimizationProps) {
  const [currentRoute, setCurrentRoute] = useState(null)
  const [optimizing, setOptimizing] = useState(false)
  const [vehicleType, setVehicleType] = useState('hearse')
  const [teamSize, setTeamSize] = useState(3)
  const [routeHistory, setRouteHistory] = useState([])

  const vehicleTypes = [
    { value: 'hearse', label: 'Hearse', icon: '⚰️', capacity: 6 },
    { value: 'limousine', label: 'Limousine', icon: '🚗', capacity: 8 },
    { value: 'van', label: 'Service Van', icon: '🚐', capacity: 12 },
    { value: 'minibus', label: 'Minibus', icon: '🚌', capacity: 16 }
  ]

  const destinations = [
    {
      id: 'home',
      name: 'Family Home',
      address: '123 Umhlanga Ridge, Durban',
      coordinates: [-29.7833, 30.9833],
      type: 'pickup',
      estimated_time: 15
    },
    {
      id: 'chapel',
      name: 'Durban Chapel',
      address: '456 Berea Road, Durban',
      coordinates: [-29.8587, 31.0218],
      type: 'service',
      estimated_time: 60
    },
    {
      id: 'cemetery',
      name: 'Stellawood Cemetery',
      address: '789 Stellawood Road, Durban',
      coordinates: [-29.8014, 31.0397],
      type: 'burial',
      estimated_time: 45
    }
  ]

  useEffect(() => {
    // Load mock route history
    setRouteHistory([
      {
        id: 'route_001',
        date: new Date(Date.now() - 86400000).toISOString(), // Yesterday
        duration: 95,
        distance: 45.2,
        efficiency: 92,
        destinations: 3,
        vehicle: 'hearse'
      },
      {
        id: 'route_002',
        date: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
        duration: 120,
        distance: 62.8,
        efficiency: 87,
        destinations: 4,
        vehicle: 'limousine'
      }
    ])
  }, [])

  const optimizeRoute = async () => {
    setOptimizing(true)
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f68dbcca/routes/optimize`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          destinations: destinations.map(d => ({
            id: d.id,
            name: d.name,
            coordinates: d.coordinates,
            type: d.type
          })),
          vehicle_type: vehicleType,
          team_size: teamSize
        })
      })

      if (response.ok) {
        const optimizedRoute = await response.json()
        setCurrentRoute(optimizedRoute.route)
        console.log('Route optimized:', optimizedRoute.route)
      } else {
        console.error('Route optimization failed:', await response.text())
        // Fallback to mock optimization
        const mockRoute = {
          route_id: `route_${Date.now()}`,
          destinations,
          vehicle_type: vehicleType,
          team_size: teamSize,
          estimated_duration: 110,
          waypoints: destinations.map((dest, index) => ({
            order: index + 1,
            location: dest,
            estimated_arrival: new Date(Date.now() + (index + 1) * 35 * 60000).toISOString()
          })),
          traffic_conditions: 'moderate',
          created_at: new Date().toISOString()
        }
        setCurrentRoute(mockRoute)
      }
    } catch (error) {
      console.error('Route optimization error:', error)
    } finally {
      setOptimizing(false)
    }
  }

  const getTrafficColor = (condition) => {
    const colors = {
      'light': 'text-green-600',
      'moderate': 'text-yellow-600',
      'heavy': 'text-red-600'
    }
    return colors[condition] || 'text-gray-600'
  }

  const getDestinationIcon = (type) => {
    const icons = {
      'pickup': '🏠',
      'service': '⛪',
      'burial': '🪦'
    }
    return icons[type] || '📍'
  }

  return (
    <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 mb-6">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Route className="w-5 h-5" />
          <span>AI Route Optimization</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Route Configuration */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Vehicle Type</label>
            <Select value={vehicleType} onValueChange={setVehicleType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {vehicleTypes.map((vehicle) => (
                  <SelectItem key={vehicle.value} value={vehicle.value}>
                    <div className="flex items-center space-x-2">
                      <span>{vehicle.icon}</span>
                      <span>{vehicle.label}</span>
                      <span className="text-xs text-gray-500">({vehicle.capacity} seats)</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Team Size</label>
            <Select value={teamSize.toString()} onValueChange={(value) => setTeamSize(parseInt(value))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[2, 3, 4, 5, 6].map((size) => (
                  <SelectItem key={size} value={size.toString()}>
                    {size} team members
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <Button 
              onClick={optimizeRoute} 
              disabled={optimizing}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {optimizing ? 'Optimizing...' : 'Optimize Route'}
            </Button>
          </div>
        </div>

        {/* Current Route Display */}
        {currentRoute && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-lg border">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-medium">Optimized Route</h4>
                <div className="flex items-center space-x-4 text-sm">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{currentRoute.estimated_duration} min</span>
                  </span>
                  <Badge className={getTrafficColor(currentRoute.traffic_conditions)}>
                    {currentRoute.traffic_conditions} traffic
                  </Badge>
                </div>
              </div>

              {/* Route Visualization */}
              <div className="relative">
                <div className="space-y-3">
                  {currentRoute.waypoints?.map((waypoint, index) => (
                    <div key={waypoint.order} className="flex items-center space-x-4">
                      <div className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {waypoint.order}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg">{getDestinationIcon(waypoint.location.type)}</span>
                          <div>
                            <p className="font-medium">{waypoint.location.name}</p>
                            <p className="text-sm text-gray-600">{waypoint.location.address}</p>
                          </div>
                        </div>
                      </div>
                      <div className="text-right text-sm">
                        <p className="text-gray-600">ETA</p>
                        <p className="font-medium">
                          {new Date(waypoint.estimated_arrival).toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Connecting Lines */}
                <div className="absolute left-4 top-8 bottom-8 w-0.5 bg-green-300"></div>
              </div>
            </div>

            {/* Route Actions */}
            <div className="flex space-x-2">
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                <Navigation className="w-4 h-4 mr-1" />
                Start Navigation
              </Button>
              <Button size="sm" variant="outline">
                <MapPin className="w-4 h-4 mr-1" />
                Share Route
              </Button>
              <Button size="sm" variant="outline">
                <Clock className="w-4 h-4 mr-1" />
                Schedule
              </Button>
            </div>
          </div>
        )}

        {/* Route Analytics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg border">
            <div className="flex items-center space-x-2 mb-2">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium">Efficiency Score</span>
            </div>
            <p className="text-2xl font-bold text-green-600">94%</p>
            <p className="text-xs text-gray-500">+2% from last route</p>
          </div>

          <div className="bg-white p-4 rounded-lg border">
            <div className="flex items-center space-x-2 mb-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">Avg. Travel Time</span>
            </div>
            <p className="text-2xl font-bold text-blue-600">12 min</p>
            <p className="text-xs text-gray-500">Between destinations</p>
          </div>

          <div className="bg-white p-4 rounded-lg border">
            <div className="flex items-center space-x-2 mb-2">
              <Car className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium">Fuel Efficiency</span>
            </div>
            <p className="text-2xl font-bold text-purple-600">8.2L</p>
            <p className="text-xs text-gray-500">Per 100km</p>
          </div>
        </div>

        {/* Route History */}
        <div className="bg-white p-4 rounded-lg border">
          <h4 className="font-medium mb-3">Recent Route History</h4>
          <div className="space-y-2">
            {routeHistory.map((route) => (
              <div key={route.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                    {vehicleTypes.find(v => v.value === route.vehicle)?.icon}
                  </div>
                  <div>
                    <p className="text-sm font-medium">
                      {new Date(route.date).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-600">
                      {route.destinations} stops • {route.distance}km
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{route.duration} min</p>
                  <div className="flex items-center space-x-1">
                    <span className="text-xs text-gray-600">Efficiency:</span>
                    <Badge variant="outline" className={route.efficiency >= 90 ? 'text-green-600' : 'text-yellow-600'}>
                      {route.efficiency}%
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Traffic & Weather Alerts */}
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-yellow-800">Route Alerts</h4>
              <div className="text-sm text-yellow-700 space-y-1 mt-1">
                <p>• Heavy traffic expected on M4 between 2-4 PM</p>
                <p>• Road construction on Berea Road - 10 min delay expected</p>
                <p>• Weather: Light rain forecasted - allow extra travel time</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}