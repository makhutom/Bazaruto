import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Textarea } from './ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { MapPin, Navigation, Clock, CheckCircle, AlertTriangle, Mic, Phone, Car, Users, Calendar } from 'lucide-react'
import { projectId } from '../utils/supabase/info'
import { supabase, isSupabaseAvailable } from '../utils/supabase/client'

interface FieldStaffViewProps {
  language: string
  translations: any
  user: any
}

export function FieldStaffView({ language, translations, user }: FieldStaffViewProps) {
  const [currentLocation, setCurrentLocation] = useState(null)
  const [currentStatus, setCurrentStatus] = useState('scheduled')
  const [statusNotes, setStatusNotes] = useState('')
  const [isTracking, setIsTracking] = useState(false)
  const [assignments, setAssignments] = useState([])
  const [loading, setLoading] = useState(false)

  const statusOptions = [
    { value: 'scheduled', label: 'Scheduled', icon: Clock, color: 'bg-blue-600' },
    { value: 'enroute', label: 'En Route', icon: Navigation, color: 'bg-yellow-600' },
    { value: 'active', label: 'Active/On Site', icon: Users, color: 'bg-green-600' },
    { value: 'completed', label: 'Completed', icon: CheckCircle, color: 'bg-gray-600' },
    { value: 'emergency', label: 'Emergency', icon: AlertTriangle, color: 'bg-red-600' }
  ]

  // Mock assignments for demonstration
  useEffect(() => {
    setAssignments([
      {
        id: 'SVC-001',
        family_name: 'Mbeki Family',
        service_type: 'Funeral Service',
        location: 'Stellawood Cemetery',
        scheduled_time: '10:00 AM',
        notes: 'Traditional Zulu ceremony requested',
        status: 'scheduled'
      },
      {
        id: 'SVC-002',
        family_name: 'Dlamini Family',
        service_type: 'Memorial Service',
        location: 'Durban Chapel',
        scheduled_time: '2:00 PM',
        notes: 'Private family gathering',
        status: 'enroute'
      }
    ])
  }, [])

  const updateLocation = async () => {
    setLoading(true)
    try {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
          const location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            status: currentStatus,
            notes: statusNotes
          }

          // Get access token for authenticated requests
          let accessToken = null
          if (isSupabaseAvailable()) {
            const { data: { session }, error } = await supabase.auth.getSession()
            if (session?.access_token) {
              accessToken = session.access_token
            }
          }

          if (accessToken) {
            console.log('🔍 Updating location with access token...')
            const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f68dbcca/location/update`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(location)
            })

            if (response.ok) {
              setCurrentLocation(location)
              console.log('✅ Location updated successfully')
            } else {
              const errorText = await response.text()
              console.error('❌ Failed to update location:', errorText)
              // Still update local state for demo purposes
              setCurrentLocation(location)
            }
          } else {
            console.log('⚠️ No access token available, updating local state only')
            // Update local state for demo purposes
            setCurrentLocation(location)
          }
        }, (error) => {
          console.error('❌ Geolocation error:', error)
          // Fallback to mock location for demo
          const mockLocation = {
            latitude: -29.8587,
            longitude: 31.0218,
            status: currentStatus,
            notes: statusNotes
          }
          setCurrentLocation(mockLocation)
        })
      } else {
        console.log('⚠️ Geolocation not available, using mock location')
        // Fallback to mock location
        const mockLocation = {
          latitude: -29.8587,
          longitude: 31.0218,
          status: currentStatus,
          notes: statusNotes
        }
        setCurrentLocation(mockLocation)
      }
    } catch (error) {
      console.error('❌ Location update error:', error)
      // Fallback to mock location
      const mockLocation = {
        latitude: -29.8587,
        longitude: 31.0218,
        status: currentStatus,
        notes: statusNotes
      }
      setCurrentLocation(mockLocation)
    } finally {
      setLoading(false)
    }
  }

  const toggleTracking = () => {
    setIsTracking(!isTracking)
    if (!isTracking) {
      // Start continuous tracking
      updateLocation()
      const interval = setInterval(updateLocation, 60000) // Update every minute
      return () => clearInterval(interval)
    }
  }

  const handleStatusUpdate = async () => {
    await updateLocation()
    setStatusNotes('')
  }

  const getStatusIcon = (status) => {
    const option = statusOptions.find(opt => opt.value === status)
    return option ? option.icon : Clock
  }

  const getStatusColor = (status) => {
    const option = statusOptions.find(opt => opt.value === status)
    return option ? option.color : 'bg-gray-600'
  }

  const t = translations[language]

  return (
    <div className="space-y-6">
      {/* Current Status Card */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Current Status</span>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${getStatusColor(currentStatus)}`}></div>
              <Badge variant="secondary" className={`${getStatusColor(currentStatus)} text-white`}>
                {statusOptions.find(opt => opt.value === currentStatus)?.label}
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Update Status</label>
              <Select value={currentStatus} onValueChange={setCurrentStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((option) => {
                    const Icon = option.icon
                    return (
                      <SelectItem key={option.value} value={option.value}>
                        <div className="flex items-center space-x-2">
                          <Icon className="w-4 h-4" />
                          <span>{option.label}</span>
                        </div>
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Location Tracking</label>
              <Button
                onClick={toggleTracking}
                variant={isTracking ? "destructive" : "default"}
                className="w-full"
              >
                <MapPin className="w-4 h-4 mr-2" />
                {isTracking ? 'Stop Tracking' : 'Start Tracking'}
              </Button>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Status Notes</label>
            <Textarea
              placeholder="Add notes about current status or location..."
              value={statusNotes}
              onChange={(e) => setStatusNotes(e.target.value)}
              className="min-h-[80px]"
            />
          </div>

          <Button onClick={handleStatusUpdate} disabled={loading} className="w-full">
            {loading ? 'Updating...' : 'Update Status & Location'}
          </Button>

          {currentLocation && (
            <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg">
              <p>Last Location Update:</p>
              <p>Lat: {currentLocation.latitude?.toFixed(6)}, Lng: {currentLocation.longitude?.toFixed(6)}</p>
              <p>Time: {new Date().toLocaleTimeString()}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Today's Assignments */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5" />
            <span>Today's Assignments</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {assignments.map((assignment) => {
            const StatusIcon = getStatusIcon(assignment.status)
            return (
              <div key={assignment.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{assignment.family_name}</h4>
                    <p className="text-sm text-slate-600">{assignment.service_type}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2 mb-1">
                      <StatusIcon className="w-4 h-4" />
                      <Badge variant="outline" className={`${getStatusColor(assignment.status)} text-white`}>
                        {assignment.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600">{assignment.scheduled_time}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">Location:</p>
                    <p className="text-slate-600">{assignment.location}</p>
                  </div>
                  <div>
                    <p className="font-medium">Special Notes:</p>
                    <p className="text-slate-600">{assignment.notes}</p>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">
                    <Navigation className="w-4 h-4 mr-1" />
                    Get Directions
                  </Button>
                  <Button size="sm" variant="outline">
                    <Phone className="w-4 h-4 mr-1" />
                    Contact Family
                  </Button>
                  <Button size="sm" variant="outline">
                    <AlertTriangle className="w-4 h-4 mr-1" />
                    Report Issue
                  </Button>
                </div>
              </div>
            )
          })}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-6 text-center">
            <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <h4 className="font-medium text-green-900">Mark Complete</h4>
            <p className="text-sm text-green-700 mb-3">Service completed successfully</p>
            <Button size="sm" className="bg-green-600 hover:bg-green-700">
              Complete Service
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-6 text-center">
            <Clock className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
            <h4 className="font-medium text-yellow-900">Request Delay</h4>
            <p className="text-sm text-yellow-700 mb-3">Notify of schedule changes</p>
            <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700">
              Report Delay
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
            <h4 className="font-medium text-red-900">Emergency</h4>
            <p className="text-sm text-red-700 mb-3">Immediate assistance needed</p>
            <Button size="sm" className="bg-red-600 hover:bg-red-700">
              Send Alert
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Team Communication */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5" />
            <span>Team Communication</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">DM</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Dispatch Manager</p>
                <p className="text-xs text-slate-600">Traffic on M4 - consider alternate route</p>
              </div>
              <span className="text-xs text-slate-500">2 min ago</span>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">SD</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Sarah Dlamini</p>
                <p className="text-xs text-slate-600">Chapel service completed on time</p>
              </div>
              <span className="text-xs text-slate-500">5 min ago</span>
            </div>
          </div>

          <div className="mt-4 flex space-x-2">
            <Button size="sm" variant="outline" className="flex-1">
              <Mic className="w-4 h-4 mr-1" />
              Voice Message
            </Button>
            <Button size="sm" variant="outline" className="flex-1">
              <Phone className="w-4 h-4 mr-1" />
              Call Dispatch
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}