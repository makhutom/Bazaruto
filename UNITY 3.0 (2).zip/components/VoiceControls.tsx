import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Mic, MicOff, Volume2, VolumeX, Loader2 } from 'lucide-react'
import { projectId } from '../utils/supabase/info'
import { supabase, isSupabaseAvailable } from '../utils/supabase/client'

interface VoiceControlsProps {
  language: string
  translations: any
  user: any
}

export function VoiceControls({ language, translations, user }: VoiceControlsProps) {
  const [isListening, setIsListening] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [processedResult, setProcessedResult] = useState(null)
  const [recognition, setRecognition] = useState(null)
  const [isSupported, setIsSupported] = useState(false)

  useEffect(() => {
    // Check for speech recognition support
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      const recognizer = new SpeechRecognition()
      
      recognizer.continuous = false
      recognizer.interimResults = false
      recognizer.lang = language === 'zu' ? 'zu-ZA' : 'en-ZA'

      recognizer.onstart = () => {
        setIsListening(true)
        setTranscript('')
        setProcessedResult(null)
      }

      recognizer.onresult = async (event) => {
        const result = event.results[0][0].transcript
        setTranscript(result)
        setIsListening(false)
        await processVoiceCommand(result)
      }

      recognizer.onerror = (event) => {
        console.error('Speech recognition error:', event.error)
        setIsListening(false)
        setIsProcessing(false)
      }

      recognizer.onend = () => {
        setIsListening(false)
      }

      setRecognition(recognizer)
      setIsSupported(true)
    } else {
      setIsSupported(false)
      console.warn('Speech recognition not supported in this browser')
    }
  }, [language])

  const processVoiceCommand = async (voiceInput) => {
    setIsProcessing(true)
    try {
      // Get access token for authenticated requests
      let accessToken = null
      if (isSupabaseAvailable()) {
        const { data: { session }, error } = await supabase.auth.getSession()
        if (session?.access_token) {
          accessToken = session.access_token
        }
      }

      if (accessToken) {
        console.log('🔍 Processing voice command with access token...')
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f68dbcca/voice/process`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ transcript: voiceInput })
        })

        if (response.ok) {
          const result = await response.json()
          console.log('✅ Voice command processed successfully:', result)
          setProcessedResult(result.processed)
          
          // Provide audio feedback
          if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(
              `Status updated to ${result.processed.status}`
            )
            utterance.lang = language === 'zu' ? 'zu-ZA' : 'en-ZA'
            speechSynthesis.speak(utterance)
          }
        } else {
          const errorText = await response.text()
          console.error('❌ Voice processing failed:', errorText)
          // Use mock processing result
          setProcessedResult(getMockProcessingResult(voiceInput))
        }
      } else {
        console.log('⚠️ No access token available, using mock voice processing')
        // Use mock processing result
        setProcessedResult(getMockProcessingResult(voiceInput))
      }
    } catch (error) {
      console.error('❌ Voice processing error:', error)
      // Use mock processing result
      setProcessedResult(getMockProcessingResult(voiceInput))
    } finally {
      setIsProcessing(false)
    }
  }

  const getMockProcessingResult = (voiceInput) => {
    const input = voiceInput.toLowerCase()
    
    if (input.includes('emergency') || input.includes('help') || input.includes('urgent')) {
      return {
        status: 'emergency',
        tags: ['emergency', 'urgent_assistance'],
        priority: 'critical'
      }
    } else if (input.includes('completed') || input.includes('finished') || input.includes('done')) {
      return {
        status: 'completed',
        tags: ['service_complete', 'success'],
        priority: 'normal'
      }
    } else if (input.includes('arrived') || input.includes('on site') || input.includes('at location')) {
      return {
        status: 'on_site',
        tags: ['location_update', 'arrived'],
        priority: 'normal'
      }
    } else if (input.includes('delayed') || input.includes('late') || input.includes('traffic')) {
      return {
        status: 'delayed',
        tags: ['delay', 'traffic_issue'],
        priority: 'high'
      }
    } else {
      return {
        status: 'unknown',
        tags: ['general_update'],
        priority: 'normal'
      }
    }
  }

  const startListening = () => {
    if (recognition && !isListening) {
      recognition.start()
    }
  }

  const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop()
    }
  }

  const getStatusColor = (status) => {
    const colors = {
      'on_site': 'bg-green-600',
      'delayed': 'bg-yellow-600',
      'emergency': 'bg-red-600',
      'completed': 'bg-gray-600',
      'error': 'bg-red-600',
      'unknown': 'bg-slate-600'
    }
    return colors[status] || 'bg-slate-600'
  }

  const getPriorityColor = (priority) => {
    const colors = {
      'critical': 'bg-red-600',
      'high': 'bg-orange-600',
      'normal': 'bg-blue-600',
      'low': 'bg-gray-600'
    }
    return colors[priority] || 'bg-blue-600'
  }

  if (!isSupported) {
    return (
      <Card className="bg-gradient-to-r from-slate-50 to-slate-100 border-slate-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <MicOff className="w-5 h-5 text-slate-400" />
            <p className="text-sm text-slate-600">
              Voice controls are not supported in this browser. Please use a modern browser with speech recognition support.
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 mb-6">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Mic className="w-5 h-5" />
          <span>Voice Control Center</span>
          {language === 'zu' && <span className="text-sm text-blue-600">(Zulu Speech Recognition)</span>}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Voice Input Section */}
        <div className="flex items-center space-x-4">
          <Button
            onClick={isListening ? stopListening : startListening}
            disabled={isProcessing}
            className={`flex-shrink-0 ${
              isListening 
                ? 'bg-red-600 hover:bg-red-700 text-white' 
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
            size="lg"
          >
            {isProcessing ? (
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
            ) : isListening ? (
              <MicOff className="w-5 h-5 mr-2" />
            ) : (
              <Mic className="w-5 h-5 mr-2" />
            )}
            {isProcessing ? 'Processing...' : isListening ? 'Stop Listening' : 'Start Voice Command'}
          </Button>

          {isListening && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-red-600 font-medium">Listening...</span>
            </div>
          )}
        </div>

        {/* Transcript Display */}
        {transcript && (
          <div className="bg-white p-4 rounded-lg border">
            <h4 className="text-sm font-medium text-slate-700 mb-2">Voice Input:</h4>
            <p className="text-slate-900 italic">"{transcript}"</p>
          </div>
        )}

        {/* AI Processing Results */}
        {processedResult && (
          <div className="bg-white p-4 rounded-lg border space-y-3">
            <h4 className="text-sm font-medium text-slate-700">AI Processing Result:</h4>
            
            <div className="flex items-center space-x-3">
              <Badge className={`${getStatusColor(processedResult.status)} text-white`}>
                Status: {processedResult.status}
              </Badge>
              <Badge className={`${getPriorityColor(processedResult.priority)} text-white`}>
                Priority: {processedResult.priority}
              </Badge>
            </div>

            {processedResult.tags && processedResult.tags.length > 0 && (
              <div>
                <p className="text-sm text-slate-600 mb-1">Detected Tags:</p>
                <div className="flex flex-wrap gap-1">
                  {processedResult.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Voice Command Examples */}
        <div className="bg-slate-50 p-4 rounded-lg">
          <h4 className="text-sm font-medium text-slate-700 mb-3">Voice Command Examples:</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
            <div className="space-y-1">
              <p className="font-medium text-slate-600">Status Updates:</p>
              <ul className="space-y-1 text-slate-500">
                <li>• "Arrived at chapel with the family"</li>
                <li>• "Service completed successfully"</li>
                <li>• "En route to cemetery"</li>
              </ul>
            </div>
            <div className="space-y-1">
              <p className="font-medium text-slate-600">Emergency/Issues:</p>
              <ul className="space-y-1 text-slate-500">
                <li>• "Vehicle broke down near hospital"</li>
                <li>• "Emergency assistance needed"</li>
                <li>• "Running late due to traffic"</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Zulu Language Examples */}
        {language === 'zu' && (
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-blue-700 mb-3">Izibonelo Zemiyalo YesiZulu:</h4>
            <div className="text-xs space-y-1">
              <p className="text-blue-600">• "Sifikile esontweni nomndeni"</p>
              <p className="text-blue-600">• "Umsebenzi uphelile ngempumelelo"</p>
              <p className="text-blue-600">• "Sidinga usizo lwephuthumayo"</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}