import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Button } from './ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { MapPin, Users, Clock, TrendingUp, AlertTriangle, CheckCircle, Navigation, Phone, Car } from 'lucide-react'
import { projectId } from '../utils/supabase/info'
import { supabase, isSupabaseAvailable } from '../utils/supabase/client'

interface DashboardViewProps {
  language: string
  translations: any
  user: any
}

export function DashboardView({ language, translations, user }: DashboardViewProps) {
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedTeam, setSelectedTeam] = useState(null)

  const statusColors = {
    scheduled: 'bg-blue-600',
    enroute: 'bg-yellow-600',
    active: 'bg-green-600',
    completed: 'bg-gray-600',
    emergency: 'bg-red-600'
  }

  const statusIcons = {
    scheduled: Clock,
    enroute: Navigation,
    active: Users,
    completed: CheckCircle,
    emergency: AlertTriangle
  }

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        let accessToken = null
        
        // Get the current user's access token
        if (isSupabaseAvailable()) {
          const { data: { session }, error } = await supabase.auth.getSession()
          if (session?.access_token) {
            accessToken = session.access_token
          }
        }

        // Use access token if available, otherwise fallback to mock data
        if (accessToken) {
          console.log('🔍 Fetching dashboard data with access token...')
          const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f68dbcca/dashboard/teams`, {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json'
            }
          })

          if (response.ok) {
            const data = await response.json()
            console.log('✅ Dashboard data fetched successfully:', data)
            setDashboardData(data)
          } else {
            const errorText = await response.text()
            console.error('❌ Failed to fetch dashboard data:', errorText)
            // Use mock data fallback
            setDashboardData(getMockDashboardData())
          }
        } else {
          console.log('⚠️ No access token available, using mock data')
          // Use mock data when no authentication
          setDashboardData(getMockDashboardData())
        }
      } catch (error) {
        console.error('❌ Dashboard fetch error:', error)
        // Use mock data fallback
        setDashboardData(getMockDashboardData())
      } finally {
        setLoading(false)
      }
    }

    const getMockDashboardData = () => ({
      active_teams: 8,
      teams: [
        {
          user_id: '1',
          user_name: 'John Mbeki',
          user_role: 'field_staff',
          latitude: -29.8587,
          longitude: 31.0218,
          status: 'enroute',
          notes: 'Proceeding to Stellawood Cemetery',
          timestamp: new Date().toISOString()
        },
        {
          user_id: '2',
          user_name: 'Sarah Dlamini',
          user_role: 'driver',
          latitude: -29.8014,
          longitude: 31.0397,
          status: 'active',
          notes: 'Service in progress at chapel',
          timestamp: new Date().toISOString()
        },
        {
          user_id: '3',
          user_name: 'David Nkomo',
          user_role: 'field_staff',
          latitude: -29.7833,
          longitude: 30.9833,
          status: 'completed',
          notes: 'Service completed successfully',
          timestamp: new Date().toISOString()
        },
        {
          user_id: '4',
          user_name: 'Nomsa Zulu',
          user_role: 'field_staff',
          latitude: -29.8400,
          longitude: 31.0100,
          status: 'scheduled',
          notes: 'Preparing for morning service',
          timestamp: new Date().toISOString()
        }
      ],
      summary: {
        scheduled: 2,
        enroute: 3,
        active: 2,
        completed: 1,
        emergency: 0
      }
    })

    fetchDashboardData()
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchDashboardData, 30000)
    return () => clearInterval(interval)
  }, [user])

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(2)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-64 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const t = translations[language]

  return (
    <div className="space-y-6">
      {/* Authentication Status Info */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Users className="w-4 h-4 text-white" />
              </div>
              <div>
                <h4 className="font-medium text-blue-900">Management Dashboard</h4>
                <p className="text-sm text-blue-700">Real-time team coordination and operations overview</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-blue-600">Logged in as:</p>
              <p className="font-medium text-blue-900">{user?.user_metadata?.name || user?.email || 'Demo User'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Status Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">Scheduled</p>
                <p className="text-2xl font-bold text-blue-900">{dashboardData?.summary?.scheduled || 0}</p>
              </div>
              <Clock className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">En Route</p>
                <p className="text-2xl font-bold text-yellow-900">{dashboardData?.summary?.enroute || 0}</p>
              </div>
              <Navigation className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">Active</p>
                <p className="text-2xl font-bold text-green-900">{dashboardData?.summary?.active || 0}</p>
              </div>
              <Users className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-gray-900">{dashboardData?.summary?.completed || 0}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-600">Emergency</p>
                <p className="text-2xl font-bold text-red-900">{dashboardData?.summary?.emergency || 0}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard Content */}
      <Tabs defaultValue="map" className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="map">Live Map</TabsTrigger>
          <TabsTrigger value="teams">Team Status</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Live Map View */}
        <TabsContent value="map" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="w-5 h-5" />
                <span>Real-time Team Locations</span>
                <Badge variant="outline" className="ml-auto">
                  {dashboardData?.teams?.length || 0} Active Teams
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative h-96 bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg overflow-hidden">
                {/* Simulated Map Background */}
                <div className="absolute inset-0 bg-green-100 opacity-30"></div>
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-slate-100/50"></div>
                
                {/* Map Content */}
                <div className="absolute inset-4 space-y-2">
                  <div className="text-sm font-medium text-slate-700 mb-4">Durban Metropolitan Area</div>
                  
                  {dashboardData?.teams?.map((team, index) => {
                    const StatusIcon = statusIcons[team.status]
                    return (
                      <div
                        key={team.user_id}
                        className={`absolute w-8 h-8 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-125 hover:shadow-lg ${statusColors[team.status]} shadow-md`}
                        style={{
                          left: `${60 + (index * 80) % 300}px`,
                          top: `${60 + Math.floor(index / 4) * 80}px`
                        }}
                        onClick={() => setSelectedTeam(team)}
                        title={`${team.user_name} - ${team.status}`}
                      >
                        <StatusIcon className="w-4 h-4 text-white" />
                      </div>
                    )
                  })}
                </div>

                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-md border">
                  <div className="text-xs font-medium mb-2">Status Legend</div>
                  <div className="space-y-1">
                    {Object.entries(statusColors).map(([status, color]) => (
                      <div key={status} className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${color}`}></div>
                        <span className="text-xs capitalize">{status.replace('_', ' ')}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Selected Team Details */}
              {selectedTeam && (
                <div className="mt-4 p-4 bg-slate-50 rounded-lg border">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-slate-900">{selectedTeam.user_name}</h4>
                    <Badge variant="secondary" className={`${statusColors[selectedTeam.status]} text-white`}>
                      {selectedTeam.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">{selectedTeam.notes}</p>
                  <div className="flex items-center space-x-4 text-xs text-slate-500">
                    <span>Role: {selectedTeam.user_role}</span>
                    <span>Lat: {selectedTeam.latitude?.toFixed(4)}</span>
                    <span>Lng: {selectedTeam.longitude?.toFixed(4)}</span>
                    <span>Updated: {new Date(selectedTeam.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="mt-3 flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Phone className="w-4 h-4 mr-1" />
                      Contact
                    </Button>
                    <Button size="sm" variant="outline">
                      <Navigation className="w-4 h-4 mr-1" />
                      Track Route
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Team Status List */}
        <TabsContent value="teams" className="space-y-4">
          {dashboardData?.teams?.map((team) => {
            const StatusIcon = statusIcons[team.status]
            return (
              <Card key={team.user_id} className="transition-shadow hover:shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${statusColors[team.status]}`}>
                        <StatusIcon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900">{team.user_name}</h4>
                        <p className="text-sm text-slate-600">{team.user_role}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary" className={`${statusColors[team.status]} text-white mb-2`}>
                        {team.status}
                      </Badge>
                      <p className="text-xs text-slate-500">
                        {new Date(team.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  {team.notes && (
                    <p className="mt-3 text-sm text-slate-700">{team.notes}</p>
                  )}
                  <div className="mt-3 flex items-center space-x-2">
                    <Button size="sm" variant="outline">
                      <Phone className="w-4 h-4 mr-1" />
                      Contact
                    </Button>
                    <Button size="sm" variant="outline">
                      <MapPin className="w-4 h-4 mr-1" />
                      Track
                    </Button>
                    <Button size="sm" variant="outline">
                      <Navigation className="w-4 h-4 mr-1" />
                      Route
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Performance Metrics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Response Time</span>
                    <span className="font-medium text-green-600">12 minutes</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Services Completed Today</span>
                    <span className="font-medium">{dashboardData?.summary?.completed || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Team Efficiency</span>
                    <span className="font-medium text-green-600">92%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Customer Satisfaction</span>
                    <span className="font-medium text-green-600">4.8/5</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Teams</span>
                    <span className="font-medium">{dashboardData?.teams?.length || 0}/12</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resource Allocation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Teams Deployed</span>
                      <span>{dashboardData?.teams?.length || 0}/12</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${((dashboardData?.teams?.length || 0) / 12) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Vehicles Active</span>
                      <span>6/10</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Capacity Utilization</span>
                      <span>75%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-yellow-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Emergency Response</span>
                      <span className="text-green-600">Ready</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: '100%' }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}