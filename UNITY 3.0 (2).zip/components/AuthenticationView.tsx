import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { MapPin, Users, Heart, Globe, AlertTriangle } from 'lucide-react'
import { supabase, isSupabaseAvailable, getSupabaseError } from '../utils/supabase/client'
import { projectId, publicAnonKey } from '../utils/supabase/info'

interface AuthenticationViewProps {
  onLogin: (user: any, role: string) => void
  language: string
  translations: any
}

export function AuthenticationView({ onLogin, language, translations }: AuthenticationViewProps) {
  const [isLogin, setIsLogin] = useState(true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    phone: '',
    role: 'field_staff'
  })

  const t = translations[language]

  const roles = [
    { value: 'management', label: 'Management', icon: Users, description: 'Oversee operations and team coordination' },
    { value: 'director', label: 'Director', icon: Heart, description: 'Executive oversight and strategic planning' },
    { value: 'field_staff', label: 'Field Staff', icon: MapPin, description: 'On-site service coordination' },
    { value: 'driver', label: 'Driver', icon: MapPin, description: 'Transportation and logistics' },
    { value: 'family', label: 'Family Member', icon: Heart, description: 'Track service progress for loved ones' }
  ]

  const handleDemoLogin = (role) => {
    console.log('Demo login for role:', role)
    const demoUser = {
      id: 'demo-' + role,
      email: `${role}@thandanani.co.za`,
      user_metadata: {
        name: `Demo ${role.charAt(0).toUpperCase() + role.slice(1).replace('_', ' ')}`,
        role: role,
        phone: '+27 11 123 4567'
      }
    }
    onLogin(demoUser, role)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      if (!isSupabaseAvailable()) {
        // Fallback to demo login if Supabase is not available
        console.log('Supabase not available, using demo login')
        handleDemoLogin(formData.role)
        return
      }

      if (isLogin) {
        // Login
        const { data, error } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password
        })

        if (error) {
          console.error('Login error:', error.message)
          setError('Login failed: ' + error.message)
        } else if (data?.user) {
          console.log('Login successful:', data.user)
          onLogin(data.user, data.user.user_metadata?.role || 'field_staff')
        }
      } else {
        // Signup
        try {
          const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f68dbcca/auth/signup`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              email: formData.email,
              password: formData.password,
              name: formData.name,
              phone: formData.phone,
              role: formData.role
            })
          })

          if (response.ok) {
            const data = await response.json()
            console.log('Signup successful:', data.user)
            onLogin(data.user, formData.role)
          } else {
            const errorData = await response.json()
            console.error('Signup error:', errorData.error)
            setError('Signup failed: ' + errorData.error)
          }
        } catch (fetchError) {
          console.error('Signup fetch error:', fetchError)
          // Fallback to demo login
          handleDemoLogin(formData.role)
        }
      }
    } catch (error) {
      console.error('Authentication error:', error)
      setError('Authentication failed: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    if (error) setError('') // Clear error when user starts typing
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <MapPin className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">{t?.title || 'Thandanani MemorialOS'}</h1>
          <p className="text-blue-200">Memorial Operations Management System</p>
          
          {/* Cultural Elements */}
          <div className="flex justify-center space-x-4 mt-4">
            <div className="w-3 h-3 rounded-full bg-yellow-400 opacity-70"></div>
            <div className="w-3 h-3 rounded-full bg-silver opacity-70" style={{ backgroundColor: '#C0C0C0' }}></div>
            <div className="w-3 h-3 rounded-full bg-yellow-600 opacity-70" style={{ backgroundColor: '#CD7F32' }}></div>
          </div>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{isLogin ? 'Sign In' : 'Create Account'}</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setIsLogin(!isLogin)
                  setFormData({ email: '', password: '', name: '', phone: '', role: 'field_staff' })
                  setError('')
                }}
              >
                {isLogin ? 'Sign Up' : 'Sign In'}
              </Button>
            </div>
          </CardHeader>

          <CardContent>
            {/* Error Display */}
            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            {/* Supabase Error Warning */}
            {!isSupabaseAvailable() && (
              <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800 mb-2">
                  <strong>Demo Mode:</strong> Authentication service unavailable. Use demo login buttons below.
                </p>
                <p className="text-xs text-yellow-700">Error: {getSupabaseError()}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <>
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      required
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      required
                      placeholder="+27 XX XXX XXXX"
                    />
                  </div>

                  <div>
                    <Label htmlFor="role">Role</Label>
                    <Select value={formData.role} onValueChange={(value) => handleInputChange('role', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map((role) => {
                          const Icon = role.icon
                          return (
                            <SelectItem key={role.value} value={role.value}>
                              <div className="flex items-center space-x-2">
                                <Icon className="w-4 h-4" />
                                <div>
                                  <p className="font-medium">{role.label}</p>
                                  <p className="text-xs text-slate-500">{role.description}</p>
                                </div>
                              </div>
                            </SelectItem>
                          )
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  required
                  placeholder="Enter your email"
                />
              </div>

              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  required
                  placeholder="Enter your password"
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Create Account')}
              </Button>
            </form>

            {/* Demo Login Buttons */}
            <div className="mt-6 pt-6 border-t">
              <p className="text-sm font-medium text-slate-700 mb-3">Quick Demo Access:</p>
              <div className="grid grid-cols-1 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDemoLogin('management')}
                  className="justify-start"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Management Dashboard
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDemoLogin('field_staff')}
                  className="justify-start"
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  Field Operations
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDemoLogin('family')}
                  className="justify-start"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Family Portal
                </Button>
              </div>
            </div>

            {/* Demo Account Info */}
            <div className="mt-4 pt-4 border-t">
              <p className="text-sm text-slate-600 mb-3">Or use demo credentials:</p>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span>Management:</span>
                  <span className="text-slate-500">manager@thandanani.co.za / demo123</span>
                </div>
                <div className="flex justify-between">
                  <span>Field Staff:</span>
                  <span className="text-slate-500">field@thandanani.co.za / demo123</span>
                </div>
                <div className="flex justify-between">
                  <span>Family:</span>
                  <span className="text-slate-500">family@thandanani.co.za / demo123</span>
                </div>
              </div>
            </div>

            {/* Cultural Note */}
            <div className="mt-4 p-3 bg-blue-50 rounded-lg text-center">
              <p className="text-xs text-blue-800">
                "Thandanani" means "Love Each Other" in Zulu
              </p>
              <p className="text-xs text-blue-600 mt-1">
                Honoring traditions with modern technology
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}