import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Textarea } from './ui/textarea'
import { AlertTriangle, Phone, MapPin, Clock, Users, Siren, X } from 'lucide-react'
import { projectId } from '../utils/supabase/info'
import { supabase, isSupabaseAvailable } from '../utils/supabase/client'

interface EmergencyAlertsProps {
  language: string
  translations: any
  user: any
}

export function EmergencyAlerts({ language, translations, user }: EmergencyAlertsProps) {
  const [activeAlerts, setActiveAlerts] = useState([])
  const [newAlert, setNewAlert] = useState({
    message: '',
    priority: 'high',
    location: ''
  })
  const [isCreatingAlert, setIsCreatingAlert] = useState(false)
  const [loading, setLoading] = useState(false)

  const emergencyTypes = [
    {
      type: 'medical',
      label: 'Medical Emergency',
      description: 'Health-related emergency requiring immediate attention',
      color: 'bg-red-600',
      icon: '🚑'
    },
    {
      type: 'vehicle',
      label: 'Vehicle Breakdown',
      description: 'Transportation issues affecting service delivery',
      color: 'bg-orange-600',
      icon: '🚗'
    },
    {
      type: 'weather',
      label: 'Weather Emergency',
      description: 'Severe weather conditions affecting operations',
      color: 'bg-blue-600',
      icon: '🌧️'
    },
    {
      type: 'security',
      label: 'Security Incident',
      description: 'Safety or security concerns requiring assistance',
      color: 'bg-purple-600',
      icon: '🔒'
    },
    {
      type: 'family',
      label: 'Family Emergency',
      description: 'Urgent family-related situation',
      color: 'bg-pink-600',
      icon: '👨‍👩‍👧‍👦'
    },
    {
      type: 'other',
      label: 'Other Emergency',
      description: 'Other urgent situations requiring immediate attention',
      color: 'bg-gray-600',
      icon: '⚠️'
    }
  ]

  // Mock active alerts for demonstration
  useEffect(() => {
    setActiveAlerts([
      {
        id: 'alert_001',
        user_id: 'user_2',
        user_name: 'Sarah Dlamini',
        message: 'Vehicle breakdown on M4 highway - need immediate assistance',
        priority: 'critical',
        type: 'vehicle',
        location: 'M4 Highway near Umhlanga',
        timestamp: new Date(Date.now() - 300000).toISOString(), // 5 minutes ago
        status: 'active',
        responders: ['dispatch_manager', 'field_supervisor']
      },
      {
        id: 'alert_002',
        user_id: 'user_3',
        user_name: 'David Nkomo',
        message: 'Family member collapsed during service - medical assistance required',
        priority: 'critical',
        type: 'medical',
        location: 'Stellawood Cemetery Chapel',
        timestamp: new Date(Date.now() - 600000).toISOString(), // 10 minutes ago
        status: 'responding',
        responders: ['emergency_medical', 'site_manager']
      }
    ])
  }, [])

  const createEmergencyAlert = async (alertType) => {
    setLoading(true)
    try {
      const alertData = {
        message: newAlert.message || emergencyTypes.find(t => t.type === alertType)?.description,
        priority: 'critical',
        location: newAlert.location,
        type: alertType
      }

      // Get access token for authenticated requests
      let accessToken = null
      if (isSupabaseAvailable()) {
        const { data: { session }, error } = await supabase.auth.getSession()
        if (session?.access_token) {
          accessToken = session.access_token
        }
      }

      if (accessToken) {
        console.log('🔍 Creating emergency alert with access token...')
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f68dbcca/emergency/alert`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(alertData)
        })

        if (response.ok) {
          const result = await response.json()
          console.log('✅ Emergency alert sent:', result)
          
          // Add to active alerts
          const newAlertItem = {
            ...result.alert,
            user_name: user?.user_metadata?.name || 'Unknown User',
            type: alertType,
            status: 'active',
            responders: []
          }
          setActiveAlerts(prev => [newAlertItem, ...prev])
          
          // Reset form
          setNewAlert({ message: '', priority: 'high', location: '' })
          setIsCreatingAlert(false)
          
          // Show confirmation
          alert('Emergency alert sent successfully!')
        } else {
          const errorText = await response.text()
          console.error('❌ Failed to send emergency alert:', errorText)
          // Create mock alert for demo
          createMockAlert(alertType, alertData)
        }
      } else {
        console.log('⚠️ No access token available, creating mock emergency alert')
        // Create mock alert for demo
        createMockAlert(alertType, alertData)
      }
    } catch (error) {
      console.error('❌ Emergency alert error:', error)
      // Create mock alert for demo
      createMockAlert(alertType, alertData)
    } finally {
      setLoading(false)
    }
  }

  const createMockAlert = (alertType, alertData) => {
    const mockAlert = {
      id: 'alert_' + Date.now(),
      user_id: user?.id || 'demo_user',
      user_name: user?.user_metadata?.name || user?.email || 'Demo User',
      message: alertData.message,
      priority: alertData.priority,
      type: alertType,
      location: alertData.location || 'Location not specified',
      timestamp: new Date().toISOString(),
      status: 'active',
      responders: []
    }
    
    setActiveAlerts(prev => [mockAlert, ...prev])
    
    // Reset form
    setNewAlert({ message: '', priority: 'high', location: '' })
    setIsCreatingAlert(false)
    
    // Show confirmation
    alert('Emergency alert created successfully (Demo Mode)!')
  }

  const getPriorityColor = (priority) => {
    const colors = {
      'critical': 'bg-red-600',
      'high': 'bg-orange-600',
      'medium': 'bg-yellow-600',
      'low': 'bg-blue-600'
    }
    return colors[priority] || 'bg-red-600'
  }

  const getStatusColor = (status) => {
    const colors = {
      'active': 'bg-red-600',
      'responding': 'bg-yellow-600',
      'resolved': 'bg-green-600'
    }
    return colors[status] || 'bg-red-600'
  }

  const getTimeAgo = (timestamp) => {
    const now = new Date()
    const alertTime = new Date(timestamp)
    const diffMs = now - alertTime
    const diffMins = Math.floor(diffMs / 60000)
    
    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins} min ago`
    const diffHours = Math.floor(diffMins / 60)
    return `${diffHours}h ${diffMins % 60}m ago`
  }

  return (
    <div className="space-y-6">
      {/* Emergency Header */}
      <div className="bg-gradient-to-r from-red-600 to-red-800 text-white p-6 rounded-lg">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <Siren className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Emergency Control Center</h1>
            <p className="text-red-100">Immediate response coordination</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 p-3 rounded">
            <p className="text-sm text-red-100">Active Alerts</p>
            <p className="text-xl font-bold">{activeAlerts.filter(a => a.status === 'active').length}</p>
          </div>
          <div className="bg-white/10 p-3 rounded">
            <p className="text-sm text-red-100">Responding</p>
            <p className="text-xl font-bold">{activeAlerts.filter(a => a.status === 'responding').length}</p>
          </div>
          <div className="bg-white/10 p-3 rounded">
            <p className="text-sm text-red-100">Response Time</p>
            <p className="text-xl font-bold">2.3 min</p>
          </div>
        </div>
      </div>

      {/* Quick Emergency Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Quick Emergency Response</span>
            <Button
              variant="outline"
              onClick={() => setIsCreatingAlert(!isCreatingAlert)}
            >
              {isCreatingAlert ? <X className="w-4 h-4 mr-1" /> : <AlertTriangle className="w-4 h-4 mr-1" />}
              {isCreatingAlert ? 'Cancel' : 'Custom Alert'}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isCreatingAlert && (
            <div className="mb-6 p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Emergency Details
                  </label>
                  <Textarea
                    placeholder="Describe the emergency situation..."
                    value={newAlert.message}
                    onChange={(e) => setNewAlert(prev => ({ ...prev, message: e.target.value }))}
                    className="min-h-[80px]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Location
                  </label>
                  <Textarea
                    placeholder="Specify exact location or landmark..."
                    value={newAlert.location}
                    onChange={(e) => setNewAlert(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {emergencyTypes.map((emergency) => (
              <Card key={emergency.type} className="border-2 border-gray-200 hover:border-red-300 transition-colors cursor-pointer">
                <CardContent className="p-4">
                  <div className="text-center space-y-3">
                    <div className="text-3xl">{emergency.icon}</div>
                    <h4 className="font-medium">{emergency.label}</h4>
                    <p className="text-sm text-gray-600">{emergency.description}</p>
                    <Button
                      onClick={() => createEmergencyAlert(emergency.type)}
                      disabled={loading}
                      className={`w-full ${emergency.color} hover:opacity-90 text-white`}
                    >
                      {loading ? 'Sending...' : 'Send Alert'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Emergency Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <span>Active Emergency Alerts</span>
            <Badge variant="destructive">{activeAlerts.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {activeAlerts.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <AlertTriangle className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No active emergency alerts</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeAlerts.map((alert) => (
                <div key={alert.id} className="border border-red-200 rounded-lg p-4 bg-red-50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${getPriorityColor(alert.priority)} animate-pulse`}></div>
                      <div>
                        <h4 className="font-medium text-gray-900">{alert.user_name}</h4>
                        <p className="text-sm text-gray-600">{alert.type} emergency</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={`${getStatusColor(alert.status)} text-white mb-1`}>
                        {alert.status}
                      </Badge>
                      <p className="text-xs text-gray-500">{getTimeAgo(alert.timestamp)}</p>
                    </div>
                  </div>

                  <p className="text-gray-900 mb-3">{alert.message}</p>

                  {alert.location && (
                    <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                      <MapPin className="w-4 h-4" />
                      <span>{alert.location}</span>
                    </div>
                  )}

                  {alert.responders && alert.responders.length > 0 && (
                    <div className="mb-3">
                      <p className="text-sm font-medium text-gray-700 mb-1">Responders:</p>
                      <div className="flex space-x-1">
                        {alert.responders.map((responder, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {responder}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-2">
                    <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
                      <Phone className="w-4 h-4 mr-1" />
                      Call Now
                    </Button>
                    <Button size="sm" variant="outline">
                      <MapPin className="w-4 h-4 mr-1" />
                      Navigate
                    </Button>
                    <Button size="sm" variant="outline">
                      <Users className="w-4 h-4 mr-1" />
                      Assign Team
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Emergency Contacts */}
      <Card>
        <CardHeader>
          <CardTitle>Emergency Contacts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-medium text-gray-700">Internal Emergency Contacts</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Emergency Coordinator</span>
                  <Button size="sm" variant="outline">
                    <Phone className="w-4 h-4 mr-1" />
                    Call
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Site Manager</span>
                  <Button size="sm" variant="outline">
                    <Phone className="w-4 h-4 mr-1" />
                    Call
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                  <span className="text-sm">Fleet Manager</span>
                  <Button size="sm" variant="outline">
                    <Phone className="w-4 h-4 mr-1" />
                    Call
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-gray-700">External Emergency Services</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center p-2 bg-red-50 rounded">
                  <span className="text-sm">Police Emergency</span>
                  <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
                    <Phone className="w-4 h-4 mr-1" />
                    10111
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 bg-red-50 rounded">
                  <span className="text-sm">Medical Emergency</span>
                  <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
                    <Phone className="w-4 h-4 mr-1" />
                    10177
                  </Button>
                </div>
                <div className="flex justify-between items-center p-2 bg-red-50 rounded">
                  <span className="text-sm">Fire Emergency</span>
                  <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
                    <Phone className="w-4 h-4 mr-1" />
                    10177
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}