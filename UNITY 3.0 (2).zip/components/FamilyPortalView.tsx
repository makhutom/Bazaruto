import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { Textarea } from './ui/textarea'
import { Heart, MapPin, Clock, Phone, Users, CheckCircle, Calendar, MessageCircle, FileText, Star } from 'lucide-react'

interface FamilyPortalViewProps {
  language: string
  translations: any
  user: any
}

export function FamilyPortalView({ language, translations, user }: FamilyPortalViewProps) {
  const [serviceDetails, setServiceDetails] = useState(null)
  const [timeline, setTimeline] = useState([])
  const [feedback, setFeedback] = useState('')
  const [rating, setRating] = useState(0)

  useEffect(() => {
    // Mock service details for family
    setServiceDetails({
      id: 'SVC-001',
      deceased_name: 'Sarah Nomsa Mbeki',
      service_date: '2025-07-20',
      service_time: '10:00 AM',
      family_name: 'Mbeki Family',
      assigned_team: {
        coordinator: 'John Dlamini',
        assistant: 'Mary Nkomo',
        driver: 'Peter Zulu'
      },
      locations: [
        { name: 'Family Home', address: '123 Umhlanga Ridge, Durban', time: '8:30 AM', type: 'pickup' },
        { name: 'St. Augustine Chapel', address: '456 Berea Road, Durban', time: '10:00 AM', type: 'service' },
        { name: 'Stellawood Cemetery', address: '789 Stellawood Road, Durban', time: '12:00 PM', type: 'burial' }
      ],
      special_requests: ['Traditional Zulu ceremony elements', 'White lilies arrangement', 'Family hymn: "Amazing Grace"']
    })

    // Mock service timeline
    setTimeline([
      { time: '8:15 AM', status: 'en_route', message: 'Team is en route to your location', completed: true },
      { time: '8:30 AM', status: 'arrived_home', message: 'Team has arrived at the family home', completed: true },
      { time: '10:00 AM', status: 'chapel_service', message: 'Chapel service begins', completed: false },
      { time: '12:00 PM', status: 'burial_service', message: 'Burial service begins', completed: false }
    ])
  }, [])

  const getStatusIcon = (status) => {
    const icons = { 'en_route': '🛣️', 'arrived_home': '🏠', 'chapel_service': '⛪', 'burial_service': '🌹' }
    return icons[status] || '📍'
  }

  const submitFeedback = () => {
    console.log('Feedback submitted:', { rating, feedback })
    alert('Thank you for your feedback. It helps us serve families better.')
    setFeedback('')
    setRating(0)
  }

  return (
    <div className="space-y-6">
      {/* Family Welcome Header */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-purple-900">Welcome, {serviceDetails?.family_name}</h1>
              <p className="text-purple-700">We are honored to serve during this difficult time.</p>
            </div>
          </div>

          {serviceDetails && (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/70 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Heart className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">In Memory Of</span>
                </div>
                <p className="font-bold text-purple-900">{serviceDetails.deceased_name}</p>
              </div>
              <div className="bg-white/70 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Calendar className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">Service Date</span>
                </div>
                <p className="font-bold text-purple-900">
                  {new Date(serviceDetails.service_date).toLocaleDateString()} at {serviceDetails.service_time}
                </p>
              </div>
              <div className="bg-white/70 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Users className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">Team Coordinator</span>
                </div>
                <p className="font-bold text-purple-900">{serviceDetails.assigned_team.coordinator}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs defaultValue="timeline" className="space-y-6">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
          <TabsTrigger value="timeline">Live Updates</TabsTrigger>
          <TabsTrigger value="details">Service Details</TabsTrigger>
          <TabsTrigger value="feedback">Feedback</TabsTrigger>
        </TabsList>

        {/* Live Timeline */}
        <TabsContent value="timeline">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>Today's Service Timeline</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {timeline.map((event, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      event.completed ? 'bg-green-600' : 'bg-gray-300'
                    }`}>
                      {event.completed ? (
                        <CheckCircle className="w-4 h-4 text-white" />
                      ) : (
                        <Clock className="w-4 h-4 text-gray-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg">{getStatusIcon(event.status)}</span>
                        <p className="font-medium">{event.message}</p>
                      </div>
                      <p className="text-sm text-gray-600">{event.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Service Details */}
        <TabsContent value="details">
          <Card>
            <CardHeader>
              <CardTitle>Service Details & Arrangements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Locations */}
              <div>
                <h4 className="font-medium mb-3">Service Locations</h4>
                <div className="space-y-3">
                  {serviceDetails?.locations.map((location, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <MapPin className="w-5 h-5 text-purple-600" />
                      <div className="flex-1">
                        <p className="font-medium">{location.name}</p>
                        <p className="text-sm text-gray-600">{location.address}</p>
                      </div>
                      <Badge variant="outline">{location.time}</Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Team */}
              <div>
                <h4 className="font-medium mb-3">Assigned Team</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <p className="font-medium">{serviceDetails?.assigned_team.coordinator}</p>
                    <p className="text-sm text-gray-600">Coordinator</p>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <p className="font-medium">{serviceDetails?.assigned_team.assistant}</p>
                    <p className="text-sm text-gray-600">Assistant</p>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <p className="font-medium">{serviceDetails?.assigned_team.driver}</p>
                    <p className="text-sm text-gray-600">Driver</p>
                  </div>
                </div>
              </div>

              {/* Special Requests */}
              <div>
                <h4 className="font-medium mb-3">Special Requests</h4>
                <div className="space-y-2">
                  {serviceDetails?.special_requests.map((request, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{request}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Feedback */}
        <TabsContent value="feedback">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageCircle className="w-5 h-5" />
                <span>Share Your Experience</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Service Rating</label>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-6 h-6 cursor-pointer ${
                        star <= rating ? 'text-yellow-500 fill-current' : 'text-gray-300'
                      }`}
                      onClick={() => setRating(star)}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Comments</label>
                <Textarea
                  placeholder="Please share your thoughts about our service..."
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>

              <Button onClick={submitFeedback} className="w-full bg-purple-600 hover:bg-purple-700">
                Submit Feedback
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Emergency Contact */}
      <Card className="bg-red-50 border-red-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-red-900">Need Immediate Assistance?</h4>
              <p className="text-sm text-red-700">Contact our emergency support line</p>
            </div>
            <Button className="bg-red-600 hover:bg-red-700">
              <Phone className="w-4 h-4 mr-1" />
              Call Now
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}