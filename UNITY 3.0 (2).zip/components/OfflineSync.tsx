import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { WifiOff, Wifi, RefreshCw, AlertTriangle, CheckCircle, Clock, Upload, Download, MapPin, Mic } from 'lucide-react'

interface OfflineSyncProps {
  language: string
  translations: any
}

export function OfflineSync({ language, translations }: OfflineSyncProps) {
  const [syncStatus, setSyncStatus] = useState('offline')
  const [pendingActions, setPendingActions] = useState([])
  const [lastSync, setLastSync] = useState(null)
  const [isOnline, setIsOnline] = useState(navigator.onLine)
  const [syncProgress, setSyncProgress] = useState(0)
  const [isSyncing, setIsSyncing] = useState(false)

  useEffect(() => {
    // Monitor online status
    const handleOnline = () => {
      setIsOnline(true)
      setSyncStatus('online')
      // Auto-sync when coming back online
      setTimeout(() => {
        handleSync()
      }, 1000)
    }

    const handleOffline = () => {
      setIsOnline(false)
      setSyncStatus('offline')
    }

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    // Load mock pending actions
    setPendingActions([
      {
        id: 'action_001',
        type: 'status_update',
        description: 'Status changed to "enroute" at Durban Chapel',
        timestamp: new Date(Date.now() - 300000).toISOString(),
        size: '1.2 KB',
        priority: 'high'
      },
      {
        id: 'action_002',
        type: 'location_update',
        description: 'Location update: -29.8587, 31.0218',
        timestamp: new Date(Date.now() - 180000).toISOString(),
        size: '0.8 KB',
        priority: 'medium'
      },
      {
        id: 'action_003',
        type: 'voice_note',
        description: 'Voice note: "Service completed successfully"',
        timestamp: new Date(Date.now() - 120000).toISOString(),
        size: '45 KB',
        priority: 'medium'
      }
    ])

    setLastSync(new Date(Date.now() - 900000).toISOString()) // 15 minutes ago

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  const handleSync = async () => {
    if (!isOnline) {
      console.log('Cannot sync while offline')
      return
    }

    setIsSyncing(true)
    setSyncProgress(0)

    try {
      // Simulate sync progress
      for (let i = 0; i <= 100; i += 10) {
        setSyncProgress(i)
        await new Promise(resolve => setTimeout(resolve, 200))
      }

      // Clear pending actions after successful sync
      setPendingActions([])
      setLastSync(new Date().toISOString())
      setSyncStatus('synced')

      console.log('Sync completed successfully')
    } catch (error) {
      console.error('Sync failed:', error)
      setSyncStatus('error')
    } finally {
      setIsSyncing(false)
      setSyncProgress(0)
    }
  }

  const getSyncStatusColor = () => {
    switch (syncStatus) {
      case 'online':
      case 'synced':
        return 'text-green-600'
      case 'offline':
        return 'text-red-600'
      case 'error':
        return 'text-orange-600'
      default:
        return 'text-gray-600'
    }
  }

  const getSyncStatusIcon = () => {
    switch (syncStatus) {
      case 'online':
      case 'synced':
        return <Wifi className="w-4 h-4" />
      case 'offline':
        return <WifiOff className="w-4 h-4" />
      case 'error':
        return <AlertTriangle className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'bg-red-600'
      case 'medium':
        return 'bg-yellow-600'
      case 'low':
        return 'bg-blue-600'
      default:
        return 'bg-gray-600'
    }
  }

  const getActionIcon = (type) => {
    switch (type) {
      case 'status_update':
        return <CheckCircle className="w-4 h-4" />
      case 'location_update':
        return <MapPin className="w-4 h-4" />
      case 'voice_note':
        return <Mic className="w-4 h-4" />
      default:
        return <Upload className="w-4 h-4" />
    }
  }

  const formatTimeAgo = (timestamp) => {
    const now = new Date()
    const time = new Date(timestamp)
    const diffMs = now - time
    const diffMins = Math.floor(diffMs / 60000)
    
    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins} min ago`
    const diffHours = Math.floor(diffMins / 60)
    return `${diffHours}h ${diffMins % 60}m ago`
  }

  const getTotalPendingSize = () => {
    return pendingActions.reduce((total, action) => {
      const size = parseFloat(action.size.replace(/[^\d.]/g, ''))
      const unit = action.size.includes('MB') ? 1024 : 1
      return total + (size * unit)
    }, 0)
  }

  return (
    <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200 mb-6">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={getSyncStatusColor()}>
              {getSyncStatusIcon()}
            </div>
            <span>Offline Data Sync</span>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className={`${getSyncStatusColor()} border-current`}>
              {syncStatus}
            </Badge>
            {pendingActions.length > 0 && (
              <Badge variant="destructive">
                {pendingActions.length} pending
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Sync Status */}
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium">Connection Status</h4>
            <Button
              onClick={handleSync}
              disabled={!isOnline || isSyncing}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSyncing ? (
                <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-1" />
              )}
              {isSyncing ? 'Syncing...' : 'Sync Now'}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className={`w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center ${
                isOnline ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {isOnline ? (
                  <Wifi className="w-6 h-6 text-green-600" />
                ) : (
                  <WifiOff className="w-6 h-6 text-red-600" />
                )}
              </div>
              <p className="text-sm font-medium">{isOnline ? 'Connected' : 'Offline'}</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full mx-auto mb-2 flex items-center justify-center">
                <Upload className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-sm font-medium">{pendingActions.length} Actions</p>
              <p className="text-xs text-gray-500">Waiting to sync</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full mx-auto mb-2 flex items-center justify-center">
                <Download className="w-6 h-6 text-purple-600" />
              </div>
              <p className="text-sm font-medium">{getTotalPendingSize().toFixed(1)} KB</p>
              <p className="text-xs text-gray-500">Data to upload</p>
            </div>
          </div>

          {lastSync && (
            <div className="mt-3 text-center text-xs text-gray-500">
              Last sync: {formatTimeAgo(lastSync)}
            </div>
          )}

          {/* Sync Progress */}
          {isSyncing && (
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Syncing data...</span>
                <span>{syncProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${syncProgress}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>

        {/* Pending Actions */}
        {pendingActions.length > 0 && (
          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-medium mb-3">Pending Actions</h4>
            <div className="space-y-2">
              {pendingActions.map((action) => (
                <div key={action.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center space-x-3">
                    <div className="text-gray-600">
                      {getActionIcon(action.type)}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{action.description}</p>
                      <p className="text-xs text-gray-500">
                        {formatTimeAgo(action.timestamp)} • {action.size}
                      </p>
                    </div>
                  </div>
                  <Badge className={`${getPriorityColor(action.priority)} text-white`}>
                    {action.priority}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Offline Mode Instructions */}
        {!isOnline && (
          <div className="bg-red-50 p-4 rounded-lg border border-red-200">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-red-800">Offline Mode Active</h4>
                <div className="text-sm text-red-700 mt-1 space-y-1">
                  <p>• Your data is being stored locally and will sync when connection is restored</p>
                  <p>• Continue working normally - all actions will be queued for upload</p>
                  <p>• Voice commands and location tracking will continue to function</p>
                  <p>• Some features may be limited without internet connectivity</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Data Storage Information */}
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-800">Offline Data Protection</h4>
              <div className="text-sm text-blue-700 mt-1 space-y-1">
                <p>• All data is encrypted and stored securely on your device</p>
                <p>• Automatic backup prevents data loss during network issues</p>
                <p>• Critical emergency functions remain available offline</p>
                <p>• Data integrity is verified during sync operations</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}