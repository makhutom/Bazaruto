// Import once and use a module-level singleton to prevent multiple instantiation
import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from './info'

// Global singleton storage
let _supabaseClient = null
let _initializationError = null
let _isInitialized = false

// Singleton factory function
function createSupabaseClient() {
  if (_isInitialized) {
    return { client: _supabaseClient, error: _initializationError }
  }

  try {
    console.log('🔄 Creating singleton Supabase client...')
    
    // Clear any existing auth data to prevent conflicts
    if (typeof window !== 'undefined') {
      // Clear potential old storage keys
      const keysToRemove = []
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i)
        if (key && key.includes('supabase')) {
          keysToRemove.push(key)
        }
      }
      keysToRemove.forEach(key => localStorage.removeItem(key))
      console.log('🧹 Cleared existing Supabase storage keys:', keysToRemove)
    }

    _supabaseClient = createClient(
      `https://${projectId}.supabase.co`,
      publicAnonKey,
      {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: false, // Disable to reduce conflicts
          storageKey: 'thandanani-memorial-os-auth', // Unique storage key
          storage: typeof window !== 'undefined' ? window.localStorage : undefined
        },
        global: {
          headers: {
            'X-Client-Info': 'thandanani-memorial-os'
          }
        }
      }
    )

    console.log('✅ Singleton Supabase client created successfully with storage key: thandanani-memorial-os-auth')
    _initializationError = null

  } catch (error) {
    console.error('❌ Failed to initialize singleton Supabase client:', error)
    _supabaseClient = null
    _initializationError = error
  }

  _isInitialized = true
  return { client: _supabaseClient, error: _initializationError }
}

// Initialize the singleton
const { client, error } = createSupabaseClient()

// Export the singleton instance and utilities
export const supabase = client
export const supabaseError = error

export const isSupabaseAvailable = () => {
  return _supabaseClient !== null && _initializationError === null
}

export const getSupabaseError = () => {
  return _initializationError?.message || 'Supabase client initialization failed'
}

export const getClientInfo = () => {
  return {
    hasClient: !!_supabaseClient,
    isInitialized: _isInitialized,
    error: _initializationError?.message,
    storageKey: 'thandanani-memorial-os-auth',
    timestamp: new Date().toISOString()
  }
}

// Log client info for debugging
if (typeof window !== 'undefined') {
  console.log('📊 Supabase client info:', getClientInfo())
}

// Prevent multiple client creation by freezing the exports
Object.freeze({ supabase, supabaseError, isSupabaseAvailable, getSupabaseError, getClientInfo })