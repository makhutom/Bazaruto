import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card'
import { Button } from './components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs'
import { Badge } from './components/ui/badge'
import { Separator } from './components/ui/separator'
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './components/ui/alert-dialog'
import { MapPin, Mic, Users, Route, Bell, Wifi, WifiOff, Globe, Phone, Navigation, AlertTriangle, Clock, CheckCircle, Circle, XCircle } from 'lucide-react'
import { DashboardView } from './components/DashboardView'
import { FieldStaffView } from './components/FieldStaffView'
import { FamilyPortalView } from './components/FamilyPortalView'
import { AuthenticationView } from './components/AuthenticationView'
import { EmergencyAlerts } from './components/EmergencyAlerts'
import { RouteOptimization } from './components/RouteOptimization'
import { VoiceControls } from './components/VoiceControls'
import { OfflineSync } from './components/OfflineSync'
import { supabase, isSupabaseAvailable, getSupabaseError } from './utils/supabase/client'

export default function App() {
  const [user, setUser] = useState(null)
  const [userRole, setUserRole] = useState('')
  const [currentView, setCurrentView] = useState('dashboard')
  const [isOnline, setIsOnline] = useState(navigator?.onLine ?? true)
  const [language, setLanguage] = useState('en')
  const [emergencyMode, setEmergencyMode] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [authError, setAuthError] = useState(null)

  // Language translations
  const translations = {
    en: {
      title: 'Thandanani MemorialOS',
      dashboard: 'Dashboard',
      field: 'Field Operations',
      family: 'Family Portal',
      emergency: 'Emergency',
      offline: 'Offline Mode',
      online: 'Online',
      logout: 'Logout'
    },
    zu: {
      title: 'Thandanani MemorialOS',
      dashboard: 'Ibhodi Lokwenza',
      field: 'Imisebenzi Yengadi',
      family: 'Isango Lomndeni',
      emergency: 'Isimo Esiphuthumayo',
      offline: 'Ngaphandle Kwe-intanethi',
      online: 'Ku-intanethi',
      logout: 'Phuma'
    }
  }

  const t = translations[language]

  useEffect(() => {
    console.log('🚀 App component mounted')
    
    // Check for existing session
    const checkAuth = async () => {
      try {
        if (isSupabaseAvailable()) {
          console.log('🔍 Checking for existing session...')
          const { data: { session }, error } = await supabase.auth.getSession()
          
          if (error) {
            console.error('❌ Session check error:', error)
            setAuthError(error.message)
          } else if (session?.user) {
            console.log('✅ Existing session found:', session.user.id)
            setUser(session.user)
            setUserRole(session.user.user_metadata?.role || 'field_staff')
          } else {
            console.log('ℹ️ No existing session found')
          }
        } else {
          console.log('⚠️ Supabase not available, setting auth error')
          setAuthError(getSupabaseError())
        }
      } catch (error) {
        console.error('❌ Auth check error:', error)
        setAuthError(error.message)
      } finally {
        setIsLoading(false)
      }
    }

    // Monitor online status
    const handleOnline = () => {
      console.log('Device came online')
      setIsOnline(true)
    }
    
    const handleOffline = () => {
      console.log('Device went offline')
      setIsOnline(false)
    }

    if (typeof window !== 'undefined') {
      window.addEventListener('online', handleOnline)
      window.addEventListener('offline', handleOffline)
    }

    checkAuth()

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('online', handleOnline)
        window.removeEventListener('offline', handleOffline)
      }
    }
  }, [])

  const handleLogin = (userData, role) => {
    console.log('Login successful:', userData, role)
    setUser(userData)
    setUserRole(role)
    setAuthError(null)
  }

  const handleLogout = async () => {
    try {
      if (isSupabaseAvailable()) {
        await supabase.auth.signOut()
      }
      setUser(null)
      setUserRole('')
      setCurrentView('dashboard')
      console.log('Logout successful')
    } catch (error) {
      console.error('Logout error:', error)
    }
  }

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'zu' : 'en')
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Thandanani MemorialOS</h1>
            <p className="text-slate-600 mb-4">Loading...</p>
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Error state
  if (authError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Connection Error</h1>
            <p className="text-slate-600 mb-4">Unable to connect to authentication service.</p>
            <p className="text-sm text-red-600 mb-4">Error: {authError}</p>
            <Button onClick={() => {
              setAuthError(null)
              setIsLoading(true)
              window.location.reload()
            }}>
              Retry Connection
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Authentication view
  if (!user) {
    return <AuthenticationView onLogin={handleLogin} language={language} translations={translations} />
  }

  const getViewForRole = () => {
    if (emergencyMode) {
      return <EmergencyAlerts language={language} translations={translations} user={user} />
    }

    switch (currentView) {
      case 'dashboard':
        if (userRole === 'management' || userRole === 'director') {
          return <DashboardView language={language} translations={translations} user={user} />
        } else {
          return <FieldStaffView language={language} translations={translations} user={user} />
        }
      case 'field':
        return <FieldStaffView language={language} translations={translations} user={user} />
      case 'family':
        return <FamilyPortalView language={language} translations={translations} user={user} />
      default:
        return <DashboardView language={language} translations={translations} user={user} />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo and Title */}
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">{t.title}</h1>
                <p className="text-sm text-slate-600">{user?.user_metadata?.name || user?.email || 'User'}</p>
              </div>
            </div>

            {/* Status Indicators */}
            <div className="flex items-center space-x-4">
              {/* Online/Offline Status */}
              <div className="flex items-center space-x-2">
                {isOnline ? (
                  <Wifi className="w-4 h-4 text-green-600" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-600" />
                )}
                <span className="text-sm text-slate-600">
                  {isOnline ? t.online : t.offline}
                </span>
              </div>

              {/* Language Toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={toggleLanguage}
                className="flex items-center space-x-1"
              >
                <Globe className="w-4 h-4" />
                <span>{language.toUpperCase()}</span>
              </Button>

              {/* Emergency Toggle */}
              <Button
                variant={emergencyMode ? "destructive" : "outline"}
                size="sm"
                onClick={() => setEmergencyMode(!emergencyMode)}
                className="flex items-center space-x-1"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>{t.emergency}</span>
              </Button>

              {/* Logout */}
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                {t.logout}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!emergencyMode && (
          <>
            {/* Navigation Tabs */}
            <Tabs value={currentView} onValueChange={setCurrentView} className="mb-8">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
                <TabsTrigger value="dashboard" className="flex items-center space-x-2">
                  <Users className="w-4 h-4" />
                  <span>{t.dashboard}</span>
                </TabsTrigger>
                <TabsTrigger value="field" className="flex items-center space-x-2">
                  <Navigation className="w-4 h-4" />
                  <span>{t.field}</span>
                </TabsTrigger>
                {userRole === 'family' && (
                  <TabsTrigger value="family" className="flex items-center space-x-2">
                    <Phone className="w-4 h-4" />
                    <span>{t.family}</span>
                  </TabsTrigger>
                )}
              </TabsList>
            </Tabs>

            {/* Offline Sync Status */}
            {!isOnline && <OfflineSync language={language} translations={translations} />}
          </>
        )}

        {/* Voice Controls (always available) */}
        <VoiceControls language={language} translations={translations} user={user} />

        {/* Route Optimization (for field staff) */}
        {(userRole === 'field_staff' || userRole === 'driver') && currentView === 'field' && !emergencyMode && (
          <RouteOptimization language={language} translations={translations} user={user} />
        )}

        {/* Main View */}
        {getViewForRole()}
      </main>

      {/* Cultural Memorial Elements */}
      <div className="fixed bottom-4 left-4 opacity-20">
        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-600"></div>
      </div>
    </div>
  )
}