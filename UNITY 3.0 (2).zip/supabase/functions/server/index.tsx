import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'

const app = new Hono()

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}))

app.use('*', logger(console.log))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// Authentication routes
app.post('/make-server-f68dbcca/auth/signup', async (c) => {
  try {
    const { email, password, role, name, phone } = await c.req.json()
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role, phone },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      console.log(`Registration error for ${email}: ${error.message}`)
      return c.json({ error: error.message }, 400)
    }

    // Store user profile in KV store
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      role,
      phone,
      created_at: new Date().toISOString(),
      status: 'active'
    })

    return c.json({ user: data.user })
  } catch (error) {
    console.log(`Signup processing error: ${error}`)
    return c.json({ error: 'Failed to process signup' }, 500)
  }
})

// Team location tracking
app.post('/make-server-f68dbcca/location/update', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { latitude, longitude, status, notes } = await c.req.json()
    
    const locationUpdate = {
      user_id: user.id,
      latitude,
      longitude,
      status,
      notes,
      timestamp: new Date().toISOString()
    }

    // Store location update
    await kv.set(`location:${user.id}:${Date.now()}`, locationUpdate)
    await kv.set(`location:current:${user.id}`, locationUpdate)

    // Broadcast to real-time channel (simulate with console log)
    console.log(`Location update broadcast: User ${user.id} at ${latitude},${longitude} - Status: ${status}`)

    return c.json({ success: true, location: locationUpdate })
  } catch (error) {
    console.log(`Location update error: ${error}`)
    return c.json({ error: 'Failed to update location' }, 500)
  }
})

// Voice status processing
app.post('/make-server-f68dbcca/voice/process', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { transcript } = await c.req.json()
    
    // AI processing simulation based on training data
    let processedStatus = { status: 'unknown', tags: [], priority: 'normal' }
    
    if (transcript.toLowerCase().includes('arrived') || transcript.toLowerCase().includes('at chapel')) {
      processedStatus = { status: 'on_site', tags: ['location_verified'], priority: 'normal' }
    } else if (transcript.toLowerCase().includes('broke down') || transcript.toLowerCase().includes('vehicle')) {
      processedStatus = { status: 'delayed', tags: ['mechanical_issue'], priority: 'high' }
    } else if (transcript.toLowerCase().includes('emergency') || transcript.toLowerCase().includes('urgent')) {
      processedStatus = { status: 'emergency', tags: ['immediate_attention'], priority: 'critical' }
    } else if (transcript.toLowerCase().includes('completed') || transcript.toLowerCase().includes('finished')) {
      processedStatus = { status: 'completed', tags: ['service_complete'], priority: 'normal' }
    }

    const voiceUpdate = {
      user_id: user.id,
      transcript,
      processed_status: processedStatus,
      timestamp: new Date().toISOString()
    }

    await kv.set(`voice:${user.id}:${Date.now()}`, voiceUpdate)

    return c.json({ success: true, processed: processedStatus })
  } catch (error) {
    console.log(`Voice processing error: ${error}`)
    return c.json({ error: 'Failed to process voice update' }, 500)
  }
})

// Route optimization
app.post('/make-server-f68dbcca/routes/optimize', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { destinations, vehicle_type, team_size } = await c.req.json()
    
    // Simulate route optimization based on training data
    const optimizedRoute = {
      route_id: `route_${Date.now()}`,
      destinations,
      vehicle_type,
      team_size,
      estimated_duration: Math.floor(Math.random() * 120) + 30, // 30-150 minutes
      waypoints: destinations.map((dest: any, index: number) => ({
        order: index + 1,
        location: dest,
        estimated_arrival: new Date(Date.now() + (index + 1) * 30 * 60000).toISOString()
      })),
      traffic_conditions: ['light', 'moderate', 'heavy'][Math.floor(Math.random() * 3)],
      created_at: new Date().toISOString()
    }

    await kv.set(`route:${optimizedRoute.route_id}`, optimizedRoute)

    return c.json({ success: true, route: optimizedRoute })
  } catch (error) {
    console.log(`Route optimization error: ${error}`)
    return c.json({ error: 'Failed to optimize route' }, 500)
  }
})

// Get team status dashboard data
app.get('/make-server-f68dbcca/dashboard/teams', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    // Get all current team locations
    const locationKeys = await kv.getByPrefix('location:current:')
    const teams = locationKeys.map(item => item.value)

    // Get user profiles for team members
    const userKeys = await kv.getByPrefix('user:')
    const users = userKeys.map(item => item.value)

    const dashboardData = {
      active_teams: teams.length,
      teams: teams.map(location => {
        const userProfile = users.find(u => u.id === location.user_id)
        return {
          ...location,
          user_name: userProfile?.name || 'Unknown',
          user_role: userProfile?.role || 'field_staff'
        }
      }),
      summary: {
        scheduled: teams.filter(t => t.status === 'scheduled').length,
        enroute: teams.filter(t => t.status === 'enroute').length,
        active: teams.filter(t => t.status === 'active').length,
        completed: teams.filter(t => t.status === 'completed').length,
        emergency: teams.filter(t => t.status === 'emergency').length
      }
    }

    return c.json(dashboardData)
  } catch (error) {
    console.log(`Dashboard data fetch error: ${error}`)
    return c.json({ error: 'Failed to fetch dashboard data' }, 500)
  }
})

// Emergency alert broadcasting
app.post('/make-server-f68dbcca/emergency/alert', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { message, priority, location } = await c.req.json()
    
    const alert = {
      id: `alert_${Date.now()}`,
      user_id: user.id,
      message,
      priority,
      location,
      timestamp: new Date().toISOString(),
      status: 'active'
    }

    await kv.set(`alert:${alert.id}`, alert)
    
    // Simulate broadcasting to all team members
    console.log(`EMERGENCY ALERT BROADCAST: ${message} from user ${user.id}`)

    return c.json({ success: true, alert })
  } catch (error) {
    console.log(`Emergency alert error: ${error}`)
    return c.json({ error: 'Failed to send emergency alert' }, 500)
  }
})

// Health check
app.get('/make-server-f68dbcca/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

Deno.serve(app.fetch)